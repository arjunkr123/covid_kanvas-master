Coronavirus Flat
================

Designer: Becris . (https://www.iconfinder.com/becris)
License: Creative Commons Attribution-Share Alike 3.0 Unported License (http://creativecommons.org/licenses/by-sa/3.0/)
