Covid 19
========

Designer: Just Icon (https://www.iconfinder.com/justicon)
License: Creative Commons (Attribution 3.0 Unported) (http://creativecommons.org/licenses/by/3.0/)
