Hand washing
============

Designer: Siwat V (https://www.iconfinder.com/antto)
License: Creative Commons Attribution-Share Alike 3.0 Unported License (http://creativecommons.org/licenses/by-sa/3.0/)
