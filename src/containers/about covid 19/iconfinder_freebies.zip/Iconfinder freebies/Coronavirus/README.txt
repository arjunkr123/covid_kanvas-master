Coronavirus
===========

Designer: dDara (https://www.iconfinder.com/dDara)
