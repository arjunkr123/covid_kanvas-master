Coronavirus
===========

Designer: Photo3idea studio (https://www.iconfinder.com/photo3idea)
License: Creative Commons Attribution-Share Alike 3.0 Unported License (http://creativecommons.org/licenses/by-sa/3.0/)
