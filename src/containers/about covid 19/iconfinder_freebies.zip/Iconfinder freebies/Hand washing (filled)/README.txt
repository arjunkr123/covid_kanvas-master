Hand washing (filled)
=====================

Designer: Arana Graphics (https://www.iconfinder.com/aranagraphics)
License: Creative Commons (Attribution-Share Alike 3.0 Unported) (http://creativecommons.org/licenses/by-sa/3.0/)
